-- phpMyAdmin SQL Dump
-- version 4.0.4.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Aug 18, 2014 at 11:38 PM
-- Server version: 5.5.32
-- PHP Version: 5.4.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `so_db`
--
CREATE DATABASE IF NOT EXISTS `so_db` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `so_db`;

-- --------------------------------------------------------

--
-- Table structure for table `fit_sq_detail`
--

CREATE TABLE IF NOT EXISTS `fit_sq_detail` (
  `ctrl_id` int(11) NOT NULL AUTO_INCREMENT,
  `sq_main_id` int(11) NOT NULL,
  `category` varchar(255) NOT NULL,
  `brand_id` int(11) NOT NULL,
  `item_name` varchar(255) NOT NULL,
  `quantity` int(11) NOT NULL,
  `uom` varchar(255) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `total_price` decimal(10,2) NOT NULL,
  `dealer_price` decimal(10,2) NOT NULL,
  `margin` int(11) NOT NULL,
  `vat_type` varchar(255) NOT NULL,
  `free1` varchar(255) NOT NULL,
  `amount1` decimal(10,2) NOT NULL,
  `free2` varchar(255) NOT NULL,
  `amount2` decimal(10,2) NOT NULL,
  `free3` varchar(255) NOT NULL,
  `amount3` decimal(10,2) NOT NULL,
  `note` longtext NOT NULL,
  `availability` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  PRIMARY KEY (`ctrl_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `fit_sq_detail`
--

INSERT INTO `fit_sq_detail` (`ctrl_id`, `sq_main_id`, `category`, `brand_id`, `item_name`, `quantity`, `uom`, `price`, `total_price`, `dealer_price`, `margin`, `vat_type`, `free1`, `amount1`, `free2`, `amount2`, `free3`, `amount3`, `note`, `availability`, `status`) VALUES
(1, 1, 'Category 1', 16, 'G480', 1, 'Pieces', '15000.00', '15000.00', '13000.00', 13, 'Vat-Include', '', '0.00', '', '0.00', '', '0.00', 'Laptop', 'On Stock', 'Delivered'),
(2, 1, 'Category 1', 16, 'G480', 1, 'Pieces', '15000.00', '15000.00', '13000.00', 13, 'Vat-Include', '', '0.00', '', '0.00', '', '0.00', 'Laptop', 'On Stock', 'Rejected');

-- --------------------------------------------------------

--
-- Table structure for table `fit_sq_main`
--

CREATE TABLE IF NOT EXISTS `fit_sq_main` (
  `ctrl_id` int(11) NOT NULL AUTO_INCREMENT,
  `sqno` varchar(255) NOT NULL,
  `company_id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `contact_no` varchar(255) NOT NULL,
  `faxno` varchar(255) NOT NULL,
  `todeliver` longtext NOT NULL,
  `tobill` longtext NOT NULL,
  `attention` varchar(255) NOT NULL,
  `availability` longtext NOT NULL,
  `terms_id` int(11) NOT NULL,
  `delivery` longtext NOT NULL,
  `validity` longtext NOT NULL,
  `cancellation` longtext NOT NULL,
  `status` varchar(255) NOT NULL,
  `revision` int(11) NOT NULL,
  `create_date` datetime NOT NULL,
  PRIMARY KEY (`ctrl_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `fit_sq_main`
--

INSERT INTO `fit_sq_main` (`ctrl_id`, `sqno`, `company_id`, `email`, `contact_no`, `faxno`, `todeliver`, `tobill`, `attention`, `availability`, `terms_id`, `delivery`, `validity`, `cancellation`, `status`, `revision`, `create_date`) VALUES
(1, 'KP140818001', 2, 'abs.cbn@yahoo.com.ph', '123-4567', '123-4567', 'Philippines', 'Philippines', 'Manager', 'For Item on-stock, please allow 3-5 days to process order. For items not on-stock, please allow 30-45 days eadtime.', 1, 'Free delivery for PO with minimum order of Php 5,000.00 within Metro Manila, and mimimum amount of Php 10,000.00 for Laguna, Batangas and Cavite.', 'Price quoted is valid for 15 days from date of quotation.', 'A 25% restocking fee (based on purchase order amount) for cancelled or returned orders, likewise product exchanges and only be done 3 days after delivery. Order basis items cannot be returned nor cancelled.', 'Confirmed', 0, '2014-08-18 11:16:42');

-- --------------------------------------------------------

--
-- Table structure for table `jump_sq_detail`
--

CREATE TABLE IF NOT EXISTS `jump_sq_detail` (
  `ctrl_id` int(11) NOT NULL AUTO_INCREMENT,
  `sq_main_id` int(11) NOT NULL,
  `category` varchar(255) NOT NULL,
  `brand_id` int(11) NOT NULL,
  `item_name` varchar(255) NOT NULL,
  `quantity` int(11) NOT NULL,
  `uom` varchar(255) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `total_price` decimal(10,2) NOT NULL,
  `dealer_price` decimal(10,2) NOT NULL,
  `margin` int(11) NOT NULL,
  `vat_type` varchar(255) NOT NULL,
  `free1` varchar(255) NOT NULL,
  `amount1` decimal(10,2) NOT NULL,
  `free2` varchar(255) NOT NULL,
  `amount2` decimal(10,2) NOT NULL,
  `free3` varchar(255) NOT NULL,
  `amount3` decimal(10,2) NOT NULL,
  `note` longtext NOT NULL,
  `availability` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  PRIMARY KEY (`ctrl_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `jump_sq_main`
--

CREATE TABLE IF NOT EXISTS `jump_sq_main` (
  `ctrl_id` int(11) NOT NULL AUTO_INCREMENT,
  `sqno` varchar(255) NOT NULL,
  `company_id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `contact_no` varchar(255) NOT NULL,
  `faxno` varchar(255) NOT NULL,
  `todeliver` longtext NOT NULL,
  `tobill` longtext NOT NULL,
  `attention` varchar(255) NOT NULL,
  `availability` longtext NOT NULL,
  `terms_id` int(11) NOT NULL,
  `delivery` longtext NOT NULL,
  `validity` longtext NOT NULL,
  `cancellation` longtext NOT NULL,
  `status` varchar(255) NOT NULL,
  `revision` int(11) NOT NULL,
  `create_date` datetime NOT NULL,
  PRIMARY KEY (`ctrl_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `ssi_sq_detail`
--

CREATE TABLE IF NOT EXISTS `ssi_sq_detail` (
  `ctrl_id` int(11) NOT NULL AUTO_INCREMENT,
  `sq_main_id` int(11) NOT NULL,
  `category` varchar(255) NOT NULL,
  `brand_id` int(11) NOT NULL,
  `item_name` varchar(255) NOT NULL,
  `quantity` int(11) NOT NULL,
  `uom` varchar(255) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `total_price` decimal(10,2) NOT NULL,
  `dealer_price` decimal(10,2) NOT NULL,
  `margin` int(11) NOT NULL,
  `vat_type` varchar(255) NOT NULL,
  `free1` varchar(255) NOT NULL,
  `amount1` decimal(10,2) NOT NULL,
  `free2` varchar(255) NOT NULL,
  `amount2` decimal(10,2) NOT NULL,
  `free3` varchar(255) NOT NULL,
  `amount3` decimal(10,2) NOT NULL,
  `note` longtext NOT NULL,
  `availability` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  PRIMARY KEY (`ctrl_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `ssi_sq_main`
--

CREATE TABLE IF NOT EXISTS `ssi_sq_main` (
  `ctrl_id` int(11) NOT NULL AUTO_INCREMENT,
  `sqno` varchar(255) NOT NULL,
  `company_id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `contact_no` varchar(255) NOT NULL,
  `faxno` varchar(255) NOT NULL,
  `todeliver` longtext NOT NULL,
  `tobill` longtext NOT NULL,
  `attention` varchar(255) NOT NULL,
  `availability` longtext NOT NULL,
  `terms_id` int(11) NOT NULL,
  `delivery` longtext NOT NULL,
  `validity` longtext NOT NULL,
  `cancellation` longtext NOT NULL,
  `status` varchar(255) NOT NULL,
  `revision` int(11) NOT NULL,
  `create_date` datetime NOT NULL,
  PRIMARY KEY (`ctrl_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_brand`
--

CREATE TABLE IF NOT EXISTS `tbl_brand` (
  `ctrl_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`ctrl_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=25 ;

--
-- Dumping data for table `tbl_brand`
--

INSERT INTO `tbl_brand` (`ctrl_id`, `name`) VALUES
(1, 'ABS Computer Technologies'),
(2, 'Ace Computers'),
(3, 'Acer'),
(4, 'ASRock'),
(5, 'Apple'),
(6, 'Asus'),
(7, 'Chip PC'),
(8, 'Dell'),
(9, 'Alienware'),
(10, 'Hewlett-Packard'),
(11, 'IBM'),
(12, 'Intel'),
(13, 'Jetta International'),
(14, 'Kontron AG'),
(15, 'LanSlide Gaming PCs'),
(16, 'Lenovo'),
(17, 'LG'),
(18, 'Medion'),
(19, 'Micron'),
(20, 'Microsoft');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_company`
--

CREATE TABLE IF NOT EXISTS `tbl_company` (
  `ctrl_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`ctrl_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=25 ;

--
-- Dumping data for table `tbl_company`
--

INSERT INTO `tbl_company` (`ctrl_id`, `name`) VALUES
(1, 'AtomIT'),
(2, 'ABS-CBN Corporation'),
(3, 'Aliw Broadcasting Corporation'),
(4, 'Eagle Broadcasting Corporation'),
(5, 'GMA Network, Inc.'),
(6, 'Manila Broadcasting Company'),
(7, 'Manila Bulletin'),
(8, 'Manila Times'),
(9, 'Philippine Broadcasting Service'),
(10, 'Philippine Star'),
(11, 'Pinoy Exchange'),
(12, 'Radio Mindanao Network Inc.'),
(13, 'Regal Entertainment'),
(14, 'Solar Entertainment Corporation'),
(15, 'Star Cinema'),
(16, 'Tiger 22 Media Corporation'),
(17, 'Viva Entertainment'),
(18, 'ZOE Broadcasting Network');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_login`
--

CREATE TABLE IF NOT EXISTS `tbl_login` (
  `ctrl_id` int(11) NOT NULL AUTO_INCREMENT,
  `fname` varchar(255) NOT NULL,
  `lname` varchar(255) NOT NULL,
  `mname` varchar(255) NOT NULL,
  `uname` varchar(255) NOT NULL,
  `upass` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_cs NOT NULL,
  `cnum` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `position` varchar(255) NOT NULL,
  `initial` tinytext NOT NULL,
  `company` varchar(255) NOT NULL,
  PRIMARY KEY (`ctrl_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `tbl_login`
--

INSERT INTO `tbl_login` (`ctrl_id`, `fname`, `lname`, `mname`, `uname`, `upass`, `cnum`, `email`, `position`, `initial`, `company`) VALUES
(1, 'Admin', 'Admin', 'Admin', 'admins', 'admins', 'Admin', 'Admin', 'Administrator', 'AD', 'All'),
(4, 'Kevin Christopher', 'Ponsones', '', 'jump', 'jump', '123-4567', 'kevin.ponsones@yahoo.com', 'Supervisor', 'KP', 'JUMP'),
(5, 'Kevin Christopher', 'Ponsones', '', 'fit', 'fit', '123-4567', 'kevin.ponsones@yahoo.com', 'Supervisor', 'KP', 'FIT'),
(6, 'Kevin Christopher', 'Ponsones', '', 'ssi', 'ssi', '123-4567', 'kevin.ponsones@yahoo.com', 'Supervisor', 'KP', 'SSI');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_terms`
--

CREATE TABLE IF NOT EXISTS `tbl_terms` (
  `ctrl_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`ctrl_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `tbl_terms`
--

INSERT INTO `tbl_terms` (`ctrl_id`, `name`) VALUES
(1, 'Term 1'),
(2, 'Term 2'),
(3, 'Term 3'),
(4, 'Term 4');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
