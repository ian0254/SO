-- phpMyAdmin SQL Dump
-- version 4.0.4.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Aug 18, 2014 at 11:40 PM
-- Server version: 5.5.32
-- PHP Version: 5.4.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `so_db`
--
CREATE DATABASE IF NOT EXISTS `so_db` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `so_db`;

-- --------------------------------------------------------

--
-- Table structure for table `fit_sq_detail`
--

CREATE TABLE IF NOT EXISTS `fit_sq_detail` (
  `ctrl_id` int(11) NOT NULL AUTO_INCREMENT,
  `sq_main_id` int(11) NOT NULL,
  `category` varchar(255) NOT NULL,
  `brand_id` int(11) NOT NULL,
  `item_name` varchar(255) NOT NULL,
  `quantity` int(11) NOT NULL,
  `uom` varchar(255) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `total_price` decimal(10,2) NOT NULL,
  `dealer_price` decimal(10,2) NOT NULL,
  `margin` int(11) NOT NULL,
  `vat_type` varchar(255) NOT NULL,
  `free1` varchar(255) NOT NULL,
  `amount1` decimal(10,2) NOT NULL,
  `free2` varchar(255) NOT NULL,
  `amount2` decimal(10,2) NOT NULL,
  `free3` varchar(255) NOT NULL,
  `amount3` decimal(10,2) NOT NULL,
  `note` longtext NOT NULL,
  `availability` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  PRIMARY KEY (`ctrl_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `fit_sq_main`
--

CREATE TABLE IF NOT EXISTS `fit_sq_main` (
  `ctrl_id` int(11) NOT NULL AUTO_INCREMENT,
  `sqno` varchar(255) NOT NULL,
  `company_id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `contact_no` varchar(255) NOT NULL,
  `faxno` varchar(255) NOT NULL,
  `todeliver` longtext NOT NULL,
  `tobill` longtext NOT NULL,
  `attention` varchar(255) NOT NULL,
  `availability` longtext NOT NULL,
  `terms_id` int(11) NOT NULL,
  `delivery` longtext NOT NULL,
  `validity` longtext NOT NULL,
  `cancellation` longtext NOT NULL,
  `status` varchar(255) NOT NULL,
  `revision` int(11) NOT NULL,
  `create_date` datetime NOT NULL,
  PRIMARY KEY (`ctrl_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `jump_sq_detail`
--

CREATE TABLE IF NOT EXISTS `jump_sq_detail` (
  `ctrl_id` int(11) NOT NULL AUTO_INCREMENT,
  `sq_main_id` int(11) NOT NULL,
  `category` varchar(255) NOT NULL,
  `brand_id` int(11) NOT NULL,
  `item_name` varchar(255) NOT NULL,
  `quantity` int(11) NOT NULL,
  `uom` varchar(255) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `total_price` decimal(10,2) NOT NULL,
  `dealer_price` decimal(10,2) NOT NULL,
  `margin` int(11) NOT NULL,
  `vat_type` varchar(255) NOT NULL,
  `free1` varchar(255) NOT NULL,
  `amount1` decimal(10,2) NOT NULL,
  `free2` varchar(255) NOT NULL,
  `amount2` decimal(10,2) NOT NULL,
  `free3` varchar(255) NOT NULL,
  `amount3` decimal(10,2) NOT NULL,
  `note` longtext NOT NULL,
  `availability` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  PRIMARY KEY (`ctrl_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `jump_sq_main`
--

CREATE TABLE IF NOT EXISTS `jump_sq_main` (
  `ctrl_id` int(11) NOT NULL AUTO_INCREMENT,
  `sqno` varchar(255) NOT NULL,
  `company_id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `contact_no` varchar(255) NOT NULL,
  `faxno` varchar(255) NOT NULL,
  `todeliver` longtext NOT NULL,
  `tobill` longtext NOT NULL,
  `attention` varchar(255) NOT NULL,
  `availability` longtext NOT NULL,
  `terms_id` int(11) NOT NULL,
  `delivery` longtext NOT NULL,
  `validity` longtext NOT NULL,
  `cancellation` longtext NOT NULL,
  `status` varchar(255) NOT NULL,
  `revision` int(11) NOT NULL,
  `create_date` datetime NOT NULL,
  PRIMARY KEY (`ctrl_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `ssi_sq_detail`
--

CREATE TABLE IF NOT EXISTS `ssi_sq_detail` (
  `ctrl_id` int(11) NOT NULL AUTO_INCREMENT,
  `sq_main_id` int(11) NOT NULL,
  `category` varchar(255) NOT NULL,
  `brand_id` int(11) NOT NULL,
  `item_name` varchar(255) NOT NULL,
  `quantity` int(11) NOT NULL,
  `uom` varchar(255) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `total_price` decimal(10,2) NOT NULL,
  `dealer_price` decimal(10,2) NOT NULL,
  `margin` int(11) NOT NULL,
  `vat_type` varchar(255) NOT NULL,
  `free1` varchar(255) NOT NULL,
  `amount1` decimal(10,2) NOT NULL,
  `free2` varchar(255) NOT NULL,
  `amount2` decimal(10,2) NOT NULL,
  `free3` varchar(255) NOT NULL,
  `amount3` decimal(10,2) NOT NULL,
  `note` longtext NOT NULL,
  `availability` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  PRIMARY KEY (`ctrl_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `ssi_sq_main`
--

CREATE TABLE IF NOT EXISTS `ssi_sq_main` (
  `ctrl_id` int(11) NOT NULL AUTO_INCREMENT,
  `sqno` varchar(255) NOT NULL,
  `company_id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `contact_no` varchar(255) NOT NULL,
  `faxno` varchar(255) NOT NULL,
  `todeliver` longtext NOT NULL,
  `tobill` longtext NOT NULL,
  `attention` varchar(255) NOT NULL,
  `availability` longtext NOT NULL,
  `terms_id` int(11) NOT NULL,
  `delivery` longtext NOT NULL,
  `validity` longtext NOT NULL,
  `cancellation` longtext NOT NULL,
  `status` varchar(255) NOT NULL,
  `revision` int(11) NOT NULL,
  `create_date` datetime NOT NULL,
  PRIMARY KEY (`ctrl_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_brand`
--

CREATE TABLE IF NOT EXISTS `tbl_brand` (
  `ctrl_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`ctrl_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_company`
--

CREATE TABLE IF NOT EXISTS `tbl_company` (
  `ctrl_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`ctrl_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_login`
--

CREATE TABLE IF NOT EXISTS `tbl_login` (
  `ctrl_id` int(11) NOT NULL AUTO_INCREMENT,
  `fname` varchar(255) NOT NULL,
  `lname` varchar(255) NOT NULL,
  `mname` varchar(255) NOT NULL,
  `uname` varchar(255) NOT NULL,
  `upass` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_cs NOT NULL,
  `cnum` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `position` varchar(255) NOT NULL,
  `initial` tinytext NOT NULL,
  `company` varchar(255) NOT NULL,
  PRIMARY KEY (`ctrl_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tbl_login`
--

INSERT INTO `tbl_login` (`ctrl_id`, `fname`, `lname`, `mname`, `uname`, `upass`, `cnum`, `email`, `position`, `initial`, `company`) VALUES
(1, 'admin', 'admin', 'admin', 'admin', 'admin', '123-4567', 'admin@yahoo.com', 'Administrator', '', 'All');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_terms`
--

CREATE TABLE IF NOT EXISTS `tbl_terms` (
  `ctrl_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`ctrl_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
